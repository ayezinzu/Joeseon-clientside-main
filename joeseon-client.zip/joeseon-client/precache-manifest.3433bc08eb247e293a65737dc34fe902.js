self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba2df12101c0ece3aad0b08d7ece9f78",
    "url": "/index.html"
  },
  {
    "revision": "aa01ad601060c0dc17f2",
    "url": "/static/css/2.0b5d44dd.chunk.css"
  },
  {
    "revision": "a31ace32aafa2bdda6cf",
    "url": "/static/css/main.39b4b217.chunk.css"
  },
  {
    "revision": "aa01ad601060c0dc17f2",
    "url": "/static/js/2.c3984201.chunk.js"
  },
  {
    "revision": "609352ea6af9e0ac98be5b5fe36b1f6a",
    "url": "/static/js/2.c3984201.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a31ace32aafa2bdda6cf",
    "url": "/static/js/main.4a561767.chunk.js"
  },
  {
    "revision": "906842e06c2708b8e295",
    "url": "/static/js/runtime-main.90e76721.js"
  },
  {
    "revision": "37c6f486472566821a4e1cd269146fb2",
    "url": "/static/media/authBanner.37c6f486.png"
  },
  {
    "revision": "5321c8fab384eb266e2abc1e997f37a5",
    "url": "/static/media/logoBlackBackground.5321c8fa.png"
  },
  {
    "revision": "f044715b18fa3afeb90c96a0db2e7f62",
    "url": "/static/media/logoPinkBackground.f044715b.png"
  },
  {
    "revision": "9970ce2e126140da7fbf6e4348abf100",
    "url": "/static/media/newsBackground.9970ce2e.png"
  },
  {
    "revision": "051e6e86f632a0083667a44b10b33615",
    "url": "/static/media/userAvatar.051e6e86.png"
  }
]);